# Sonic 8D Music Player

A fresh Android project with a local music library and a local video player.

## Features
- Scans audio and video stored on the device.
- Music and video tabs.
- ExoPlayer playback with previous, play/pause, next and seek controls.
- Android Equalizer, BassBoost and Virtualizer controls where supported by the device.
- GitHub Actions workflow builds a debug APK.

## Build
Push the project to the `main` branch. GitHub Actions runs **Build Sonic 8D APK**.
Download `Sonic-8D-Music-Player-debug` from the completed workflow run's Artifacts section.

## Important
- Android audio effects are device-dependent. Virtualizer is not the same as a true head-tracked 8D mix.
- This project has source/configuration files; the APK must be built by GitHub Actions and tested on a phone.
