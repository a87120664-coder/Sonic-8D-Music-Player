# Sonic 8D Music Player v2
Native Android project using Media3 ExoPlayer.
Features: local music/video scan, playback, animated spectrum-style visual, individual device EQ bands, Bass Boost, Android Virtualizer surround control, HD mode information toggle, dark neon theme, vector app mark, landscape/fullscreen video toggle.
Important: Virtualizer is not a custom rotating 8D DSP. Visualizer is animated artwork, not FFT analysis. HD toggle does not upsample audio. Effects depend on device support. Test the APK on a real device before release.
Build with JDK 17: `gradle assembleDebug`.
