# Sonic 8D Music Player

Fresh Android project with local music and video libraries, Media3 playback, Equalizer/Bass Boost/Virtualizer controls, animated spectrum visualization, and an HD Audio Mode indicator.

## Build
Open with Android Studio or run `gradle assembleDebug` using JDK 17 and Gradle 8.9.

## Notes
- HD Audio Mode preserves playback from the original media source; it cannot create detail absent from a file or force hardware Hi-Res support.
- Equalizer, Bass Boost and Virtualizer availability varies by Android device and audio output.
- The spectrum is an animated visualizer effect, not a hardware audio-frequency analyzer.
- The project has not been compiled or tested on a physical phone in this environment. Use GitHub Actions to validate the build, then test playback and permissions on your Android device.
