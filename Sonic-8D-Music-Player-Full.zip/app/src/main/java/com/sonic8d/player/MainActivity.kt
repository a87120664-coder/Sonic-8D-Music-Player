package com.sonic8d.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.*
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import android.media.audiofx.Equalizer
import android.media.audiofx.BassBoost
import android.media.audiofx.Virtualizer
import kotlin.math.sin

private data class Track(val name: String, val uri: Uri)

class MainActivity : AppCompatActivity() {
    private lateinit var player: ExoPlayer
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var message: TextView
    private lateinit var spectrum: Spectrum
    private lateinit var videoFrame: FrameLayout
    private val songs = mutableListOf<Track>()
    private val videos = mutableListOf<Track>()
    private var tab = "MUSIC"
    private var hd = false
    private var fullscreen = false
    private var equalizer: Equalizer? = null
    private var bass: BassBoost? = null
    private var surround: Virtualizer? = null
    private val cyan = 0xFF20C8FF.toInt()
    private val purple = 0xFF9B5CFF.toInt()
    private val white = 0xFFF2F7FF.toInt()
    private val muted = 0xFF9CB1C9.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF070B14.toInt()
        window.navigationBarColor = 0xFF070B14.toInt()
        player = ExoPlayer.Builder(this).build()
        player.setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { spectrum.playing = isPlaying; spectrum.invalidate() }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_BUFFERING) message.text = "Preparing media…"
                if (state == Player.STATE_ENDED) message.text = "Playback finished"
            }
        })
        buildUi()
        askPermission()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(8))
            setBackgroundColor(0xFF070B14.toInt())
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "ϟ"; textSize = 42f; gravity = Gravity.CENTER
            setTextColor(cyan); setBackgroundColor(0xFF10283D.toInt())
        }, LinearLayout.LayoutParams(dp(58), dp(58)))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
        brand.addView(TextView(this).apply { text = "SONIC 8D"; textSize = 26f; setTextColor(cyan); setTypeface(null, 1) })
        brand.addView(TextView(this).apply { text = "IMMERSIVE MUSIC EXPERIENCE"; textSize = 10f; setTextColor(muted) })
        head.addView(brand)
        root.addView(head)
        head.alpha = 0f; head.translationY = dp(12).toFloat()
        head.animate().alpha(1f).translationY(0f).setDuration(700).setInterpolator(DecelerateInterpolator()).start()
        message = TextView(this).apply { text = "MUSIC • VIDEO • IMMERSIVE SOUND"; gravity = Gravity.CENTER; textSize = 11f; setTextColor(muted); setPadding(0,dp(10),0,dp(4)) }
        root.addView(message)
        spectrum = Spectrum()
        root.addView(spectrum, LinearLayout.LayoutParams(-1, dp(70)))
        val tabs = LinearLayout(this)
        tabs.addView(button("♫  MUSIC") { showMusic() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        tabs.addView(button("▣  VIDEOS") { showVideos() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        root.addView(tabs)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private inner class Spectrum : View(this@MainActivity) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        var playing = false
        private var phase = 0f
        override fun onDraw(c: Canvas) {
            val n = 40; val gap = width * .012f; val bw = (width - gap * (n + 1)) / n
            for (i in 0 until n) {
                val wave = if (playing) .18f + .72f * (.5f + .5f * sin(phase + i * .55f)) else .12f
                val h = height * wave
                p.color = if (i % 3 == 0) purple else cyan
                val x = gap + i * (bw + gap)
                c.drawRoundRect(x, (height-h)/2, x+bw, (height+h)/2, bw/2, bw/2, p)
            }
            if (playing) { phase += .16f; postInvalidateDelayed(45) }
        }
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTextColor(white)
        backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF15334A.toInt())
        setOnClickListener { animate().scaleX(.97f).scaleY(.97f).setDuration(70).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(100).start(); action()
        }.start() }
    }

    private fun askPermission() {
        val permissions = if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.READ_MEDIA_VIDEO)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        val missing = permissions.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) scan() else ActivityCompat.requestPermissions(this, missing.toTypedArray(), 72)
    }
    override fun onRequestPermissionsResult(r: Int, p: Array<out String>, g: IntArray) {
        super.onRequestPermissionsResult(r,p,g)
        if (r == 72) { if (g.any { it == PackageManager.PERMISSION_GRANTED }) scan() else message.text = "Allow media access to show phone files" }
    }

    private fun scan() {
        songs.clear(); videos.clear()
        load(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, false, songs)
        load(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, true, videos)
        if (tab == "MUSIC") showMusic() else showVideos()
        message.text = "${songs.size} songs • ${videos.size} videos found"
    }
    private fun load(uri: Uri, video: Boolean, target: MutableList<Track>) {
        val projection = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.DURATION)
        val where = if (video) "${MediaStore.Video.Media.DURATION} > 0" else "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        try {
            contentResolver.query(uri, projection, where, null, "${MediaStore.MediaColumns.DISPLAY_NAME} ASC")?.use { c ->
                val id = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
                val name = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                while (c.moveToNext()) target.add(Track(c.getString(name) ?: "Unknown", ContentUris.withAppendedId(uri,c.getLong(id))))
            }
        } catch (_: Exception) { message.text = "Could not scan this media library" }
    }

    private fun heading(t: String) {
        content.addView(TextView(this).apply { text=t; textSize=13f; setTextColor(cyan); setTypeface(null,1); setPadding(0,dp(14),0,dp(7)) })
    }
    private fun row(t: String) {
        content.addView(TextView(this).apply { text=t; textSize=13f; setTextColor(white); setPadding(dp(10),dp(12),dp(10),dp(12)) })
    }

    private fun showMusic() {
        tab = "MUSIC"; content.removeAllViews()
        heading("PLAYBACK")
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        controls.addView(button("PREVIOUS") { if (player.hasPreviousMediaItem()) player.seekToPreviousMediaItem() })
        controls.addView(button(if (player.isPlaying) "PAUSE" else "PLAY") { if (player.isPlaying) player.pause() else player.play(); showMusic() })
        controls.addView(button("NEXT") { if (player.hasNextMediaItem()) player.seekToNextMediaItem() })
        content.addView(controls)
        heading("AUDIO QUALITY")
        val hdRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        hdRow.addView(TextView(this).apply { text="HD AUDIO MODE\\nPreserves the source file's available quality"; textSize=12f; setTextColor(white) }, LinearLayout.LayoutParams(0,-2,1f))
        hdRow.addView(Switch(this).apply { isChecked=hd; setOnCheckedChangeListener { _,v -> hd=v; message.text=if(v) "HD mode on • source quality preserved" else "Standard playback" } })
        content.addView(hdRow)
        heading("SOUND ENGINE")
        slider("EQUALIZER • ALL-BAND LEVEL",50) { v -> setAllBands(v) }
        val e = equalizer
        if (e == null) row("Play a song to activate individual EQ frequency bands.")
        else {
            heading("INDIVIDUAL FREQUENCY BANDS")
            val range = e.bandLevelRange
            for (b in 0 until e.numberOfBands) {
                val freq = e.getCenterFreq(b.toShort()) / 1000
                content.addView(TextView(this).apply { text="$freq Hz"; textSize=11f; setTextColor(white) })
                content.addView(SeekBar(this).apply {
                    max = range[1].toInt() - range[0].toInt()
                    progress = (e.getBandLevel(b.toShort()).toInt() - range[0].toInt()).coerceIn(0,max)
                    setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                        override fun onProgressChanged(s:SeekBar?,v:Int,u:Boolean) { if(u) try { e.setBandLevel(b.toShort(),(v+range[0]).toShort()) } catch (_:Exception){} }
                        override fun onStartTrackingTouch(s:SeekBar?) {}
                        override fun onStopTrackingTouch(s:SeekBar?) {}
                    })
                })
            }
        }
        slider("BASS BOOST",0) { v -> try { bass?.setStrength((v*10).toShort()) } catch (_:Exception){} }
        slider("8D / SURROUND VIRTUALIZER",0) { v -> try { surround?.setStrength((v*10).toShort()) } catch (_:Exception){} }
        row("8D / Surround uses Android's Virtualizer effect. It is not a custom rotating stereo-panning engine. Support varies by device. HD mode does not upsample or restore missing audio detail.")
        heading("YOUR SONGS • ${songs.size}")
        listMedia(songs,false)
    }
    private fun slider(label:String, initial:Int, action:(Int)->Unit) {
        content.addView(TextView(this).apply { text=label; textSize=12f; setTextColor(white); setTypeface(null,1); setPadding(0,dp(6),0,0) })
        content.addView(SeekBar(this).apply { max=100; progress=initial
            setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s:SeekBar?,v:Int,u:Boolean) { if(u) action(v) }
                override fun onStartTrackingTouch(s:SeekBar?) {}
                override fun onStopTrackingTouch(s:SeekBar?) {}
            })
        })
    }
    private fun setAllBands(v:Int) {
        try { val e=equalizer ?: return; val r=e.bandLevelRange; val level=(r[0]+(r[1]-r[0])*v/100).toShort()
            for (b in 0 until e.numberOfBands) e.setBandLevel(b.toShort(),level)
        } catch (_:Exception) {}
    }

    private fun showVideos() {
        tab="VIDEOS"; content.removeAllViews()
        heading("PHONE VIDEO PLAYER")
        videoFrame=FrameLayout(this)
        val pv=PlayerView(this).apply { player=this@MainActivity.player; useController=true }
        videoFrame.addView(pv,FrameLayout.LayoutParams(-1,dp(230)))
        videoFrame.addView(Button(this).apply {
            text="⛶"; textSize=22f; setTextColor(white)
            backgroundTintList=android.content.res.ColorStateList.valueOf(0xAA10283D.toInt())
            setOnClickListener { toggleFullscreen() }
        },FrameLayout.LayoutParams(dp(54),dp(48),Gravity.END or Gravity.TOP))
        content.addView(videoFrame)
        content.addView(button("LANDSCAPE / EXIT FULLSCREEN") { toggleFullscreen() })
        heading("PHONE VIDEOS • ${videos.size}")
        listMedia(videos,true)
    }
    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        requestedOrientation = if(fullscreen) ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (fullscreen) {
            root.setPadding(0,0,0,0)
            videoFrame.layoutParams = LinearLayout.LayoutParams(-1,0,1f)
            content.removeViews(1,(content.childCount-1).coerceAtLeast(0))
        } else {
            root.setPadding(dp(16),dp(12),dp(16),dp(8))
            showVideos()
        }
    }
    private fun listMedia(items:List<Track>, video:Boolean) {
        if(items.isEmpty()) { row(if(video) "No videos found." else "No songs found."); return }
        items.forEachIndexed { i,item ->
            val tv=TextView(this).apply {
                text="${if(video) "▶" else "♫"}   ${item.name}"
                textSize=13f; setTextColor(white); setPadding(dp(12),dp(14),dp(12),dp(14))
                setBackgroundColor(if(i%2==0) 0xFF111D2D.toInt() else 0xFF0B1421.toInt())
                setOnClickListener { playList(items,i,video); message.text="NOW PLAYING • ${item.name}" }
            }
            content.addView(tv)
        }
    }
    private fun playList(items:List<Track>, index:Int, video:Boolean) {
        try {
            player.setMediaItems(items.map { MediaItem.fromUri(it.uri) },index,0L); player.prepare(); player.play()
            releaseEffects()
            if(!video) {
                player.addListener(object:Player.Listener {
                    override fun onPlaybackStateChanged(state:Int) {
                        if(state==Player.STATE_READY && equalizer==null) { attachEffects(); if(tab=="MUSIC") showMusic() }
                    }
                })
            }
        } catch (_:Exception) { message.text="Could not play this file" }
    }
    private fun attachEffects() {
        try {
            releaseEffects()
            val id=player.audioSessionId
            if(id>0) {
                equalizer=Equalizer(0,id).apply { enabled=true }
                bass=BassBoost(0,id).apply { enabled=true }
                surround=Virtualizer(0,id).apply { enabled=true }
            }
        } catch (_:Exception) { message.text="Some audio effects are unavailable on this device" }
    }
    private fun releaseEffects() {
        try { equalizer?.release() } catch (_:Exception){}
        try { bass?.release() } catch (_:Exception){}
        try { surround?.release() } catch (_:Exception){}
        equalizer=null; bass=null; surround=null
    }
    override fun onDestroy() { releaseEffects(); player.release(); super.onDestroy() }
}
